self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f2c2fa333c696aa32215798b2baf2f21",
    "url": "/index.html"
  },
  {
    "revision": "474bc5e287826a41a03a",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "d4d39bcb7840297c432b",
    "url": "/static/css/main.899c65e2.chunk.css"
  },
  {
    "revision": "474bc5e287826a41a03a",
    "url": "/static/js/2.a5f32066.chunk.js"
  },
  {
    "revision": "ea530b466e59714032d2a57c34eb302f",
    "url": "/static/js/2.a5f32066.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d4d39bcb7840297c432b",
    "url": "/static/js/main.70c3d549.chunk.js"
  },
  {
    "revision": "e1a635096941ed215cd9",
    "url": "/static/js/runtime-main.70f74ae7.js"
  },
  {
    "revision": "b7cde174c918d936b79bcb26fe280c51",
    "url": "/static/media/scissors.b7cde174.svg"
  }
]);