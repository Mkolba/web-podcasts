self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "07b6615513a9e8b1192ac574c5519f63",
    "url": "/index.html"
  },
  {
    "revision": "404678fe7fdada29c570",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "706f10474eb8c042443a",
    "url": "/static/css/main.899c65e2.chunk.css"
  },
  {
    "revision": "404678fe7fdada29c570",
    "url": "/static/js/2.546f88ab.chunk.js"
  },
  {
    "revision": "ea530b466e59714032d2a57c34eb302f",
    "url": "/static/js/2.546f88ab.chunk.js.LICENSE.txt"
  },
  {
    "revision": "706f10474eb8c042443a",
    "url": "/static/js/main.18277a2f.chunk.js"
  },
  {
    "revision": "e1a635096941ed215cd9",
    "url": "/static/js/runtime-main.70f74ae7.js"
  },
  {
    "revision": "b7cde174c918d936b79bcb26fe280c51",
    "url": "/static/media/scissors.b7cde174.svg"
  }
]);